package com.example.licenseadvisor;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RecommendationsActivity extends AppCompatActivity {

    private TextView titleTextView, recommendationsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendations);

        titleTextView = findViewById(R.id.titleTextView);
        recommendationsTextView = findViewById(R.id.recommendationsTextView);

        // Get the selected answers from the Intent or wherever you stored them
        // For this example, I'm assuming they are passed through Intent extras
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String selectedApps = extras.getString("selectedApps", "");
            displayRecommendations(selectedApps);
        }
    }

    private void displayRecommendations(String selectedApps) {
        String licenseName;

        if (!selectedApps.isEmpty()) {
            licenseName = "Creative Cloud All Apps"; // or any other appropriate license name
        } else {
            licenseName = "Standard License"; // or any other default license name
        }

        // Display the title and actual license name
        titleTextView.setText(R.string.recommendations_title);
        recommendationsTextView.setText(licenseName);
    }

}
