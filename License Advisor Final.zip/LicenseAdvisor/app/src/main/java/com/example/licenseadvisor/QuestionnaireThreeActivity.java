package com.example.licenseadvisor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionnaireThreeActivity extends AppCompatActivity {

    private RadioGroup budgetRangeRadioGroup;
    private Button generateRecommendationsButton;
    private String selectedApps; // Declare selectedApps as a class-level variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire_three);

        budgetRangeRadioGroup = findViewById(R.id.budgetRangeRadioGroup);
        generateRecommendationsButton = findViewById(R.id.generateRecommendationsButton);

        // Retrieve the selected apps from the previous activity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            selectedApps = extras.getString("selectedApps", "");
            // Display the selected apps (for testing)
            Toast.makeText(this, "Selected Apps in QuestionnaireThree: " + selectedApps, Toast.LENGTH_SHORT).show();
        }

        // Set a listener for the radio group to handle radio button selections
        budgetRangeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                // Handle the selected answer
                RadioButton radioButton = findViewById(checkedId);
                if (radioButton != null) {
                    String selectedAnswer = radioButton.getText().toString();
                    // Store the selected answer for later use in the app
                    // You can save it to SharedPreferences, a database, or another storage method
                    // For now, let's display a toast message with the selected answer
                    Toast.makeText(QuestionnaireThreeActivity.this, "Selected Answer: " + selectedAnswer, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set a click listener for the generate recommendations button
        generateRecommendationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected answer from the radio group
                int selectedId = budgetRangeRadioGroup.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    // Move to the RecommendationsActivity and pass the selected apps
                    Intent intent = new Intent(QuestionnaireThreeActivity.this, RecommendationsActivity.class);
                    intent.putExtra("selectedApps", selectedApps);
                    startActivity(intent);
                    // Finish the current activity to prevent going back to it with the back button
                    finish();
                } else {
                    // Handle the case where no answer is selected
                    Toast.makeText(QuestionnaireThreeActivity.this, "Please select an answer before generating recommendations", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
