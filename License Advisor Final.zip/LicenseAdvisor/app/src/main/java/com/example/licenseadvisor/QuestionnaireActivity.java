package com.example.licenseadvisor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionnaireActivity extends AppCompatActivity {

    private RadioGroup primaryRoleRadioGroup;
    private Button nextQuestionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire);

        primaryRoleRadioGroup = findViewById(R.id.primaryRoleRadioGroup);
        nextQuestionButton = findViewById(R.id.nextQuestionButton);

        // Set a listener for the radio group to handle radio button selections
        primaryRoleRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                // Handle the selected answer
                RadioButton radioButton = findViewById(checkedId);
                if (radioButton != null) {
                    String selectedAnswer = radioButton.getText().toString();
                    // Store the selected answer for later use in the app
                    Toast.makeText(QuestionnaireActivity.this, "Selected Answer: " + selectedAnswer, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set a click listener for the next question button
        nextQuestionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected answer from the radio group
                int selectedId = primaryRoleRadioGroup.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedAnswer = selectedRadioButton.getText().toString();

                    // Store the selected answer for later use in the app
                    Toast.makeText(QuestionnaireActivity.this, "Selected Answer: " + selectedAnswer, Toast.LENGTH_SHORT).show();

                    // Move to the next question (QuestionnaireTwoActivity)

                    Intent intent = new Intent(QuestionnaireActivity.this, QuestionnaireTwoActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    // Finish the current activity to prevent going back to it with the back button
                    finish();
                } else {
                    // Handle the case where no answer is selected
                    Toast.makeText(QuestionnaireActivity.this, "Please select an answer before moving to the next question", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
