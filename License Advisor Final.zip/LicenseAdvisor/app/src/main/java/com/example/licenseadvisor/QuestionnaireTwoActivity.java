package com.example.licenseadvisor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionnaireTwoActivity extends AppCompatActivity {

    private CheckBox acrobatCheckBox, photoshopCheckBox, illustratorCheckBox, indesignCheckBox;
    private Button nextQuestionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire_two);

        acrobatCheckBox = findViewById(R.id.acrobatCheckBox);
        photoshopCheckBox = findViewById(R.id.photoshopCheckBox);
        illustratorCheckBox = findViewById(R.id.illustratorCheckBox);
        indesignCheckBox = findViewById(R.id.indesignCheckBox);
        nextQuestionButton = findViewById(R.id.nextQuestionButton);

        // Set a click listener for the next question button
        nextQuestionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected answers
                StringBuilder selectedApps = new StringBuilder();

                if (acrobatCheckBox.isChecked()) {
                    selectedApps.append("Adobe Acrobat Pro DC, ");
                }
                if (photoshopCheckBox.isChecked()) {
                    selectedApps.append("Adobe Photoshop, ");
                }
                if (illustratorCheckBox.isChecked()) {
                    selectedApps.append("Adobe Illustrator, ");
                }
                if (indesignCheckBox.isChecked()) {
                    selectedApps.append("Adobe InDesign, ");
                }

                // Remove the trailing comma and space
                if (selectedApps.length() > 0) {
                    selectedApps.setLength(selectedApps.length() - 2);
                }

                // Display the selected apps (for testing)
                Toast.makeText(QuestionnaireTwoActivity.this, "Selected Apps: " + selectedApps.toString(), Toast.LENGTH_SHORT).show();

                // Move to the QuestionnaireThreeActivity and pass the selected apps
                Intent intent = new Intent(QuestionnaireTwoActivity.this, QuestionnaireThreeActivity.class);
                intent.putExtra("selectedApps", selectedApps.toString());
                startActivity(intent);
                // Finish the current activity to prevent going back to it with the back button
                finish();
            }
        });
    }
}