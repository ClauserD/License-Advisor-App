package com.example.licenseadvisor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileManagementActivity extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, emailEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_management);

        // Find views in the layout
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);

        // Set click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Perform login or validation logic here
                // For demonstration, we'll display a toast message with entered information
                String message = "First Name: " + firstNameEditText.getText().toString() +
                        "\nLast Name: " + lastNameEditText.getText().toString() +
                        "\nEmail: " + emailEditText.getText().toString() +
                        "\nPassword: " + passwordEditText.getText().toString();

                Toast.makeText(ProfileManagementActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
