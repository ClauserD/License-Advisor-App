package com.example.licenseadvisor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionnaireTwoActivity extends AppCompatActivity {

    private CheckBox acrobatCheckBox, photoshopCheckBox, illustratorCheckBox, indesignCheckBox;
    private Button nextQuestionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire_two);

        acrobatCheckBox = findViewById(R.id.acrobatCheckBox);
        photoshopCheckBox = findViewById(R.id.photoshopCheckBox);
        illustratorCheckBox = findViewById(R.id.illustratorCheckBox);
        indesignCheckBox = findViewById(R.id.indesignCheckBox);
        nextQuestionButton = findViewById(R.id.nextQuestionButton);

        // Set a click listener for the next question button
        nextQuestionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the selected answers
                StringBuilder selectedAnswers = new StringBuilder("Selected Answers: ");

                if (acrobatCheckBox.isChecked()) {
                    selectedAnswers.append("Adobe Acrobat Pro DC, ");
                }
                if (photoshopCheckBox.isChecked()) {
                    selectedAnswers.append("Adobe Photoshop, ");
                }
                if (illustratorCheckBox.isChecked()) {
                    selectedAnswers.append("Adobe Illustrator, ");
                }
                if (indesignCheckBox.isChecked()) {
                    selectedAnswers.append("Adobe InDesign, ");
                }

                // Remove the trailing comma and space
                if (selectedAnswers.length() > 0) {
                    selectedAnswers.setLength(selectedAnswers.length() - 2);
                }

                // Display the selected answers
                Toast.makeText(QuestionnaireTwoActivity.this, selectedAnswers.toString(), Toast.LENGTH_SHORT).show();

                // Move to the next question (QuestionnaireThreeActivity)
                startActivity(new Intent(QuestionnaireTwoActivity.this, QuestionnaireThreeActivity.class));
                // Finish the current activity to prevent going back to it with the back button
                finish();
            }
        });
    }
}