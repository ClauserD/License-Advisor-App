package com.example.licenseadvisor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        // Find the buttons in the layout
        Button profileManagementButton = findViewById(R.id.profileManagementButton);
        Button questionnaireButton = findViewById(R.id.questionnaireButton);
        Button tipsTutorialsButton = findViewById(R.id.tipsTutorialsButton);

        // Set click listeners for the buttons
        profileManagementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the ProfileManagementActivity when Profile Management button is clicked
                Intent intent = new Intent(HomeScreenActivity.this, ProfileManagementActivity.class);
                startActivity(intent);
            }
        });

        questionnaireButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the QuestionnaireActivity when Questionnaire button is clicked
                Intent intent = new Intent(HomeScreenActivity.this, QuestionnaireActivity.class);
                startActivity(intent);
            }
        });

        tipsTutorialsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the TipsTutorialsActivity when Tips and Tutorials button is clicked
                Intent intent = new Intent(HomeScreenActivity.this, TipsTutorialsActivity.class);
                startActivity(intent);
            }
        });
    }
}
